package vn.hoangtojava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoangtoSampleCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoangtoSampleCodeApplication.class, args);
	}

}
